//----------------------------------------------------------------------
//EASTRISING TECHNOLOGY CO,.LTD.//
// Module    : ER-TFT3.95-1   720*720
// Lanuage   : C51 Code
// Create    : JAVEN LIU
// Date      : 2022-10-25
// Drive IC  : LCD: NV3052C(Controller:7680)      TP:GT911
// INTERFACE : 4 wire SPI   
// MCU 		 : STC12LE5C60S2     1T MCU
// MCU VDD	 : 3.3V
// MODULE VDD : 5V OR 3.3V 
//----------------------------------------------------------------------

//===========================================================
#include <STC12C5A.H>
#include <math.h>
#include <stdio.h>
#include<stdlib.h>
#include <intrins.h>
#include"lcd.h" 
#include"demo.h" 
#include"SD.h"  
#include"TP.h"   
#include"nv3052.h"

//=============================================================


#define uchar      unsigned char
#define uint       unsigned int
#define ulong      unsigned long



/////////////////////main////////////////////
void main(void)
{  	 uchar brightness=10;
 

 	P1M0 |= (1<<3);	//CS
	P1M1 &= ~(1<<3);

	
	P3M0 |= (1<<7); // RST
	P3M1 &= ~(1<<7);

	P1M0 |= (1<<0);	  //SDI
	P1M1 &= ~(1<<0);	
	P1M0 |= (1<<1);	  //SCLK
	P1M1 &= ~(1<<1);		
	P1M0 &= ~(1<<2);  //SDO 
	P1M1 |= (1<<2);



  
   	delay_ms(100);//delay for ER power on


    ER_HW_Reset();
	System_Check_Temp();
   	delay_ms(100);
	while(LCD_StatusRead()&0x02);	 //Initial_Display_test	and  set SW2 pin2 = 1

  	ER_initial();
 	nv3052_Initial();// initialization
	 Display_ON();
	 delay_ms(20);



//	BL_ON=0;  //Backlight on when external signal control
  while(1) 
 	{

//	BL_ON=1;  //Backlight on when external signal control


   /*
	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	
    Foreground_color_65k(White);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1 ,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
 	 delay_ms(100);
 	 */
 	////////BackLight Brightness control test  whit ER's PWM0
/*	   brightness=10;
	Foreground_color_65k(White);
	Background_color_65k(Red);
	CGROM_Select_Internal_CGROM();  
 	Font_Select_8x16_16x16();
   	Goto_Text_XY(0,Line1); 
	Show_String( "BackLight Brightness control test");
	 while(brightness<=100)
	  {ER_PWM1(brightness);	
	  delay_ms(50);
	  brightness+=10;
	 }
 	///////////	   
   */

	TPTEST();
 
	Text_Demo();
 	mono_Demo();	   
	gray();
   	Geometric();
 	NextStep();

//    Display_JPG_SDCARD();
	DMA_Demo();


	}
}




	
