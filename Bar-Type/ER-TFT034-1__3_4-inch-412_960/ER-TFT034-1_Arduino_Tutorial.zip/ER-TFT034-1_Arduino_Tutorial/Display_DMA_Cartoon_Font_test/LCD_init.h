#ifndef LCD_init_h
#define LCD_init_h
#include "Arduino.h"
//#include <avr/pgmspace.h>
#include <SPI.h>

#define  SPI_CS     2
#define  SPI_CLK    1  // DUE   13
#define  SPI_DI     0 //  DUE   11 


#define  SPI_CS_RES   digitalWrite(SPI_CS, LOW)
#define  SPI_CS_SET   digitalWrite(SPI_CS, HIGH)
#define  SPI_CLK_RES   digitalWrite(SPI_CLK, LOW)
#define  SPI_CLK_SET   digitalWrite(SPI_CLK, HIGH)
#define  SPI_DI_RES   digitalWrite(SPI_DI, LOW)
#define  SPI_DI_SET   digitalWrite(SPI_DI, HIGH)



void HW_SPI_Send(unsigned char i)
{ 
  SPI.transfer( i);
}




//RGB+9b_SPI(rise)
 void SW_SPI_Send(unsigned char i)
{  
   unsigned char n;
   
   for(n=0; n<8; n++)			
   {       
			SPI_CLK_RES;
			if(i&0x80)SPI_DI_SET ;
                        else SPI_DI_RES ;

			SPI_CLK_SET;

			i<<=1;
	  
   }
}

void SPI_WriteComm(unsigned char i)
{
    SPI_CS_RES;
    SPI_DI_RES;//DI=0 COMMAND
 
    SPI_CLK_RES;
    SPI_CLK_SET;
  //  HW_SPI_Send(i);
    SW_SPI_Send(i);	
    SPI_CS_SET;	
}



void SPI_WriteData(unsigned char i)
{ 
    SPI_CS_RES;
    SPI_DI_SET;//DI=1 DATA
    SPI_CLK_RES;
    SPI_CLK_SET;
  //  HW_SPI_Send(i);   
    SW_SPI_Send(i);
    SPI_CS_SET;  		
} 


void ST7701S_Initial(void)
{  
     pinMode(SPI_CS,   OUTPUT);
    digitalWrite(SPI_CS, HIGH);
    pinMode(SPI_CLK,   OUTPUT);
    digitalWrite(SPI_CLK, LOW);
    pinMode(SPI_DI,   OUTPUT);
    digitalWrite(SPI_DI, LOW);  
  
	
 
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x13);
	SPI_WriteComm(0xEF);
	SPI_WriteData(0x08);
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x10);
	SPI_WriteComm(0xC0);
	SPI_WriteData(0x77);
	SPI_WriteData(0x00);
	SPI_WriteComm(0xC1);
	SPI_WriteData(0x0C);
	SPI_WriteData(0x0C);
	SPI_WriteComm(0xC2);
	SPI_WriteData(0x07);
	SPI_WriteData(0x02);
	SPI_WriteComm(0xCC);
	SPI_WriteData(0x10);
	SPI_WriteComm(0xB0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x0C);
	SPI_WriteData(0x19);
	SPI_WriteData(0x0B);
	SPI_WriteData(0x0F);
	SPI_WriteData(0x06);
	SPI_WriteData(0x05);
	SPI_WriteData(0x08);
	SPI_WriteData(0x08);
	SPI_WriteData(0x1F);
	SPI_WriteData(0x04);
	SPI_WriteData(0x11);
	SPI_WriteData(0x0F);
	SPI_WriteData(0x26);
	SPI_WriteData(0x2F);
	SPI_WriteData(0x1D);
	SPI_WriteComm(0xB1);
	SPI_WriteData(0x00);
	SPI_WriteData(0x17);
	SPI_WriteData(0x19);
	SPI_WriteData(0x0F);
	SPI_WriteData(0x12);
	SPI_WriteData(0x05);
	SPI_WriteData(0x05);
	SPI_WriteData(0x08);
	SPI_WriteData(0x07);
	SPI_WriteData(0x1F);
	SPI_WriteData(0x03);
	SPI_WriteData(0x10);
	SPI_WriteData(0x10);
	SPI_WriteData(0x27);
	SPI_WriteData(0x2F);
	SPI_WriteData(0x1D);
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x11);
	SPI_WriteComm(0xB0);
	SPI_WriteData(0x4D);
	SPI_WriteComm(0xB1);
	SPI_WriteData(0x4F);
	SPI_WriteComm(0xB2);
	SPI_WriteData(0x82);
	SPI_WriteComm(0xB3);
	SPI_WriteData(0x80);
	SPI_WriteComm(0xB5);
	SPI_WriteData(0x4E);
	SPI_WriteComm(0xB7);
	SPI_WriteData(0x85);
	SPI_WriteComm(0xB8);
	SPI_WriteData(0x20);
	SPI_WriteComm(0xC1);
	SPI_WriteData(0x78);
	SPI_WriteComm(0xC2);
	SPI_WriteData(0x78);
	SPI_WriteComm(0xD0);
	SPI_WriteData(0x88);
	SPI_WriteComm(0xE0); 
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x02); 
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x0C);
	SPI_WriteComm(0xE1); 
	SPI_WriteData(0x02);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x04);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x01);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x03);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x00);
	SPI_WriteData(0x44);
	SPI_WriteData(0x44);
	SPI_WriteComm(0xE2); 
	SPI_WriteData(0x03);
	SPI_WriteData(0x03);
	SPI_WriteData(0x03);
	SPI_WriteData(0x03);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0xD4);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0xD4);
	SPI_WriteData(0x00);
	SPI_WriteComm(0xE3); 
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x33);
	SPI_WriteData(0x33);
	SPI_WriteComm(0xE4); 
	SPI_WriteData(0x44);
	SPI_WriteData(0x44);
	SPI_WriteComm(0xE5); 
	SPI_WriteData(0x09);
	SPI_WriteData(0xD2);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x0B);
	SPI_WriteData(0xD4);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x05);
	SPI_WriteData(0xCE);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x07);
	SPI_WriteData(0xD0);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteComm(0xE6);  
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x33);
	SPI_WriteData(0x33);
	SPI_WriteComm(0xE7); 
	SPI_WriteData(0x44);
	SPI_WriteData(0x44);
	SPI_WriteComm(0xE8); 
	SPI_WriteData(0x08);
	SPI_WriteData(0xD1);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x0A);
	SPI_WriteData(0xD3);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x04);
	SPI_WriteData(0xCD);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteData(0x06);
	SPI_WriteData(0xCF);
	SPI_WriteData(0x35);
	SPI_WriteData(0x8C);
	SPI_WriteComm(0xEB); 
	SPI_WriteData(0x00);
	SPI_WriteData(0x01);
	SPI_WriteData(0xE4);
	SPI_WriteData(0xE4);
	SPI_WriteData(0x44);
	SPI_WriteData(0x33);
	SPI_WriteComm(0xED);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xF7);
	SPI_WriteData(0x65);
	SPI_WriteData(0x4A);
	SPI_WriteData(0x10);
	SPI_WriteData(0x3B);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xB3);
	SPI_WriteData(0x01);
	SPI_WriteData(0xA4);
	SPI_WriteData(0x56);
	SPI_WriteData(0x7F);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteComm(0xEF);
	SPI_WriteData(0x10);
	SPI_WriteData(0x0D);
	SPI_WriteData(0x04);
	SPI_WriteData(0x08);
	SPI_WriteData(0x3F);
	SPI_WriteData(0x1F);
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteComm(0x3A);
	SPI_WriteData(0x66);
	
	SPI_WriteComm(0x11);
	delay(120);
	SPI_WriteComm(0x29);
	delay(20);


}



#endif


