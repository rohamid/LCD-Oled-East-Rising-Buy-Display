


   #define layer1_start_addr 0 		 
  #define layer2_start_addr 614400  
  #define layer3_start_addr 1288000    
  #define layer4_start_addr 1843200 
  #define layer5_start_addr 2457600 
  #define layer6_start_addr 3072000  
  #define layer7_start_addr 3686400   
  #define layer8_start_addr 4300800
  #define layer9_start_addr 4915200
  #define layer10_start_addr 5529600

 #define Picture_1_Addr	  0



void ER_PWM1(unsigned short Compare_Buffer)             

{  	  
	Select_PWM1();
	Set_PWM_Prescaler_1_to_256(20);
    Select_PWM1_Clock_Divided_By_1();
	Set_Timer1_Count_Buffer(100); 
	Set_Timer1_Compare_Buffer(Compare_Buffer); 
	Start_PWM1(); 

}


void LCD_BTE_Memory_Copy
(
 unsigned long S0_Addr     // SOͼ����ڴ���ʼ��ַ
,unsigned short S0_W       // S0ͼ��Ŀ���
,unsigned short XS0        // S0ͼ������Ϸ�X����
,unsigned short YS0        // S0ͼ������Ϸ�Y����
,unsigned long S1_Addr     // S1ͼ����ڴ���ʼ��ַ
,unsigned short S1_W       // S1ͼ��Ŀ���
,unsigned short XS1        // S1ͼ������Ϸ�X����
,unsigned short YS1        // S1ͼ������Ϸ�Y����
,unsigned long Des_Addr    // Ŀ��ͼ����ڴ���ʼ��ַ
,unsigned short Des_W      // Ŀ��ͼ��Ŀ���
,unsigned short XDes       // Ŀ��ͼ������Ϸ�X����
,unsigned short YDes       // Ŀ��ͼ������Ϸ�Y����
,unsigned int ROP_Code     // ��դ����ģʽ
/*ROP_Code :
   0000b		0(Blackness)
   0001b		~S0!E~S1 or ~(S0+S1)
   0010b		~S0!ES1
   0011b		~S0
   0100b		S0!E~S1
   0101b		~S1
   0110b		S0^S1
   0111b		~S0 + ~S1 or ~(S0 + S1)
   1000b		S0!ES1
   1001b		~(S0^S1)
   1010b		S1
   1011b		~S0+S1
   1100b		S0
   1101b		S0+~S1
   1110b		S0+S1
   1111b		1(whiteness)*/
,unsigned short X_W       // ����ڵĿ���
,unsigned short Y_H       // ����ڵĳ���
)
{
	BTE_S0_Color_16bpp();
	BTE_S0_Memory_Start_Address(S0_Addr);
  BTE_S0_Image_Width(S0_W);
  BTE_S0_Window_Start_XY(XS0,YS0);

	BTE_S1_Color_16bpp();
  BTE_S1_Memory_Start_Address(S1_Addr);
  BTE_S1_Image_Width(S1_W); 
  BTE_S1_Window_Start_XY(XS1,YS1);

	BTE_Destination_Color_16bpp();
  BTE_Destination_Memory_Start_Address(Des_Addr);
  BTE_Destination_Image_Width(Des_W);
  BTE_Destination_Window_Start_XY(XDes,YDes);	
   
  BTE_ROP_Code(ROP_Code);	
  BTE_Operation_Code(0x02); //BTE Operation: Memory copy (move) with ROP.
  BTE_Window_Size(X_W,Y_H); 
  BTE_Enable();
  Check_BTE_Busy();
}


void LCD_DrawSquare_Fill
(
 unsigned short X1                // X1λ��
,unsigned short Y1                // Y1λ��
,unsigned short X2                // X2λ��
,unsigned short Y2                // Y2λ��
,unsigned long ForegroundColor    // ������ɫ
)
{
	Foreground_color_65k(ForegroundColor);
  Square_Start_XY(X1,Y1);
  Square_End_XY(X2,Y2);
  Start_Square_Fill();
  Check_2D_Busy();
}


 void LCD_DMA_24bit_Block
(
 unsigned char SCS         // ѡ����ҵ�SPI   : SCS��0       SCS��1
,unsigned char Clk         // SPIʱ�ӷ�Ƶ���� : SPI Clock = System Clock /{(Clk+1)*2}
,unsigned short X1         // ���䵽�ڴ�X1��λ��
,unsigned short Y1         // ���䵽�ڴ�Y1��λ��
,unsigned short X_W        // DMA�������ݵĿ���
,unsigned short Y_H        // DMA�������ݵĸ߶�
,unsigned short P_W        // ͼƬ�Ŀ���
,unsigned long Addr        // Flash�ĵ�ַ
)
{  

  Enable_SFlash_SPI();									          // ʹ��SPI����
  if(SCS == 0)	Select_SFI_0();										// ѡ����ҵ�SPI0
  if(SCS == 1)	Select_SFI_1();									  // ѡ����ҵ�SPI1
 
										   
  Select_SFI_DMA_Mode();								          // ����SPI��DMAģʽ
  SPI_Clock_Period(Clk);                          // ����SPI�ķ�Ƶϵ��

  Goto_Pixel_XY(X1,Y1);									          // ��ͼ��ģʽ�������ڴ��λ��
  SFI_DMA_Destination_Upper_Left_Corner(X1,Y1);		// DMA�����Ŀ�ĵأ��ڴ��λ�ã�
  SFI_DMA_Transfer_Width_Height(X_W,Y_H);				  // ���ÿ����ݵĿ��Ⱥ͸߶�
  SFI_DMA_Source_Width(P_W);							        // ����Դ���ݵĿ���
  SFI_DMA_Source_Start_Address(Addr); 					  // ����Դ������Flash�ĵ�ַ

  Start_SFI_DMA();									              // ��ʼDMA����
  Check_Busy_SFI_DMA();								            // ���DMA�Ƿ������
}






 void DMA_Demo(void)
{
  
		unsigned long i;

 ///////////////////////////////////////////////////////////////

	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	

 	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT);
	Start_Square_Fill();


    //DMA initial setting
	Enable_SFlash_SPI();
    Select_SFI_1();
    Select_SFI_DMA_Mode();
    Select_SFI_24bit_Address();

    //Select_SFI_Waveform_Mode_0();
    Select_SFI_Waveform_Mode_3();

    //Select_SFI_0_DummyRead();	//normal read mode
    Select_SFI_8_DummyRead(); //1byte dummy cycle
    //Select_SFI_06_DummyRead();
   //Select_SFI_24_DummyRead();

    //Select_SFI_Single_Mode();
    Select_SFI_Dual_Mode0();
   // Select_SFI_Dual_Mode1();

    SPI_Clock_Period(0);



	SFI_DMA_Destination_Upper_Left_Corner(0,0);
    SFI_DMA_Transfer_Width_Height(LCD_XSIZE_TFT,LCD_YSIZE_TFT);
    SFI_DMA_Source_Width(LCD_XSIZE_TFT);//

  

	 for(i=0;i<4;i++)
	 {
	  SFI_DMA_Source_Start_Address(i*LCD_XSIZE_TFT*LCD_YSIZE_TFT*2+Picture_1_Addr);//
	  Start_SFI_DMA();
      Check_Busy_SFI_DMA();
	  delay_ms(30);
 	NextStep();
	 }
   /*
 	unsigned long i;
    
	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer2_start_addr);			
	Main_Image_Width(LCD_XSIZE_TFT);
	Canvas_Image_Start_address(layer2_start_addr);	     
	Canvas_image_width(LCD_XSIZE_TFT);				       
	Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
	Main_Window_Start_XY(0,0);				                   

	LCD_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);


		for(i=0;i<4;i++)
		{		
		LCD_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,i*LCD_XSIZE_TFT*LCD_YSIZE_TFT*2);
		delay_ms(30);
    	NextStep();							
		}
 	 */
}








 void Geometric(void)
{unsigned int i;
	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	

 	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill(); delay_ms(50);


   	for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Red);
	Line_Start_XY(0+i,0+i);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Start_Square();
	delay_ms(50);
	}

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Black);
	Line_Start_XY(0+i,0+i);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Start_Square();
	delay_ms(50);
	}
 	delay_ms(2000);
///////////////////////////Square Of Circle
   	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();  delay_ms(50);

   for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Green);
	Line_Start_XY(0+i,0+i);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Circle_Square_Radius_RxRy(10,10);
	Start_Circle_Square();
	delay_ms(50);
	}

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Black);
	Line_Start_XY(0+i,0+i);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Circle_Square_Radius_RxRy(10,10);
	Start_Circle_Square();
	delay_ms(50);
	}
   	delay_ms(2000);

///////////////////////////Circle
  	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();   delay_ms(50);

   for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Blue);
	Circle_Center_XY(LCD_XSIZE_TFT/2,LCD_YSIZE_TFT/2);
	Circle_Radius_R(i);
	Start_Circle_or_Ellipse();
	delay_ms(50);
	}

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Black);
	Circle_Center_XY(LCD_XSIZE_TFT/2,LCD_YSIZE_TFT/2);
	Circle_Radius_R(i);
	Start_Circle_or_Ellipse();
	delay_ms(50);
	}
   	delay_ms(2000);

///////////////////////////Ellipse
  	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();  delay_ms(50);

   for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(White);
	Circle_Center_XY(LCD_XSIZE_TFT/2,LCD_YSIZE_TFT/2);
	Ellipse_Radius_RxRy(i,i+100);
	Start_Circle_or_Ellipse();
	delay_ms(50);
	}

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Black);
	Circle_Center_XY(LCD_XSIZE_TFT/2,LCD_YSIZE_TFT/2);
	Ellipse_Radius_RxRy(i,i+100);
	Start_Circle_or_Ellipse();
	delay_ms(50);
	}
   	delay_ms(2000);

 ////////////////////////////Triangle
   	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();  delay_ms(50);

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Yellow);
	Triangle_Point1_XY(LCD_XSIZE_TFT/2,i);
	Triangle_Point2_XY(i,LCD_YSIZE_TFT-1-i);
	Triangle_Point3_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Start_Triangle();
	delay_ms(50);
	}

    for(i=0;i<=LCD_XSIZE_TFT/2-10;i+=8)
	{Foreground_color_65k(Black);
	Triangle_Point1_XY(LCD_XSIZE_TFT/2,i);
	Triangle_Point2_XY(i,LCD_YSIZE_TFT-1-i);
	Triangle_Point3_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1-i);
	Start_Triangle();
	delay_ms(50);
	}
   	delay_ms(2000);


 ////////////////////////////line
   	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill(); delay_ms(50);

    for(i=0;i<=LCD_XSIZE_TFT;i+=8)
	{Foreground_color_65k(Red);
	Line_Start_XY(i,0);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1);
	Start_Line();
	delay_ms(50);
	}
	for(i=0;i<=LCD_YSIZE_TFT;i+=8)
	{Foreground_color_65k(Red);
	Line_Start_XY(0,LCD_YSIZE_TFT-1-i);
	Line_End_XY(LCD_XSIZE_TFT-1,i);
	Start_Line();
	delay_ms(50);
	}


    for(i=0;i<=LCD_XSIZE_TFT;i+=8)
	{Foreground_color_65k(Black);
	Line_Start_XY(i,0);
	Line_End_XY(LCD_XSIZE_TFT-1-i,LCD_YSIZE_TFT-1);
	Start_Line();
	delay_ms(50);
	}
	for(i=0;i<=LCD_YSIZE_TFT;i+=8)
	{Foreground_color_65k(Black);
	Line_Start_XY(0,LCD_YSIZE_TFT-1-i);
	Line_End_XY(LCD_XSIZE_TFT-1,i);
	Start_Line();
	delay_ms(50);
	}


   	delay_ms(2000);


}


 
void Text_Demo(void)
{	unsigned int i,j;

	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	
 
  
 	Foreground_color_65k(White);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
  	delay_ms(100);

	Foreground_color_65k(Black);
	Background_color_65k(White);
	CGROM_Select_Internal_CGROM();
	Font_Select_8x16_16x16();
	Goto_Text_XY(0,10);
	Show_String("8x16 Character");

	Font_Select_12x24_24x24();
	Goto_Text_XY(0,26);
	Show_String("12x24 Character");

	Font_Select_16x32_32x32();
	Goto_Text_XY(0,50);
	Show_String("16x32 Character");





 	  Foreground_color_65k(color65k_blue); 
	  Font_Background_select_Transparency();

  	  Active_Window_XY(0,180);
	  Active_Window_WH(80,80);
	  Goto_Pixel_XY(0,180);
	  Show_picture(80*80,pic_80x80); 
	  Active_Window_XY(0,0);
	  Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);


	  Font_Select_12x24_24x24();
	  Goto_Text_XY(0,190);
   	  Show_String("Demo text transparent");




	

	  Font_Background_select_Color();  
	  Foreground_color_65k(color65k_black); 
	  Background_color_65k(color65k_white);

	  Font_Select_8x16_16x16();
	  Goto_Text_XY(0,100);
   	  Show_String("Demo text cursor:");	 
	  Goto_Text_XY(0,124);
	  Show_String("0123456789");
/*	  Text_cursor_initial();
	 delay_ms(1000);

	  for(i=0;i<14;i++)
	  {
	   delay_ms(100);
	   Text_Cursor_H_V(1+i,15-i);	   
	  }
	  	 delay_ms(2000);

	  Disable_Text_Cursor();



	  Foreground_color_65k(color65k_blue); 
	  Goto_Text_XY(0,150);
   	  Show_String("Demo graphic cursor:");

	  Set_Graphic_Cursor_Color_1(0xff);
      Set_Graphic_Cursor_Color_2(0x00);

	  Graphic_cursor_initial();

	  Graphic_Cursor_XY(0,180);
	  Select_Graphic_Cursor_1();  
	  	 delay_ms(2000);
	  Select_Graphic_Cursor_2();
	  delay_ms(2000);
	  Select_Graphic_Cursor_3();
	  delay_ms(2000);
	  Select_Graphic_Cursor_4();
	  delay_ms(2000);
	  Select_Graphic_Cursor_2(); 

	  for(j=0;j<2;j++)
	  {
	   for(i=0;i<LCD_XSIZE_TFT;i++)
	   {
	    Graphic_Cursor_XY(i,180+j*20);	
		delay_ms(2);   
	   }
	  }
	   Graphic_Cursor_XY(0,180);	

	 delay_ms(2000);
	 Disable_Graphic_Cursor();	  */

	NextStep();


 }


 
void mono_Demo(void)
{

	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	


	Foreground_color_65k(Red);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
	Foreground_color_65k(Green);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
 	Foreground_color_65k(Blue);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
	Foreground_color_65k(Cyan);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
	Foreground_color_65k(Yellow);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
  	Foreground_color_65k(Magenta);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
 	Foreground_color_65k(White);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
  	Foreground_color_65k(Black);
	Line_Start_XY(0,0);
	Line_End_XY(LCD_XSIZE_TFT-1,LCD_YSIZE_TFT-1);
	Start_Square_Fill();
	NextStep();
}


void gray(void)
{ int i,col,line;
	Select_Main_Window_16bpp();
	Main_Image_Start_Address(layer1_start_addr);				
	Main_Image_Width(LCD_XSIZE_TFT);
	Main_Window_Start_XY(0,0);
	Canvas_Image_Start_address(layer1_start_addr);
	Canvas_image_width(LCD_XSIZE_TFT);
    Active_Window_XY(0,0);
	Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);	


	 col=0;line=0;
	for(i=0;i<32;i++)
   	{	Foreground_color_65k(i<<11);
		Line_Start_XY(col,line);
		Line_End_XY(col+LCD_XSIZE_TFT/32,line+LCD_YSIZE_TFT/4);
		Start_Square_Fill();
		col+=LCD_XSIZE_TFT/32;
	}
	  

	 col=0;line=LCD_YSIZE_TFT/4;
	for(i=0;i<64;i+=2)
   	{	Foreground_color_65k(i<<5);
		Line_Start_XY(col,line);
		Line_End_XY(col+LCD_XSIZE_TFT/32,line+LCD_YSIZE_TFT/4);
		Start_Square_Fill();
		col+=LCD_XSIZE_TFT/32;

	}


	 col=0;line=LCD_YSIZE_TFT/2;
	for(i=0;i<32;i++)
   	{	Foreground_color_65k(i);
		Line_Start_XY(col,line);
		Line_End_XY(col+LCD_XSIZE_TFT/32,line+LCD_YSIZE_TFT/4);
		Start_Square_Fill();
		col+=LCD_XSIZE_TFT/32;
	}

	 col=0;line=(LCD_YSIZE_TFT/4)*3;
	for(i=0;i<32;i++)
   	{	Foreground_color_65k((i<<11)+(i<<6)+i);
		Line_Start_XY(col,line);
		Line_End_XY(col+LCD_XSIZE_TFT/32,line+LCD_YSIZE_TFT/4);
		Start_Square_Fill();
		col+=LCD_XSIZE_TFT/32;
	}


	  delay_ms(1000);
 	NextStep();
}




